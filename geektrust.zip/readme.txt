Project Name
Mission Impossible: King Shan wants to visit the suburb of Hallitharam, and has 2 possible orbits and 3 possible vehicles to choose from.
The program will use the weather condition and traffic speed to determine which orbit and vehicle King Shan should take to reach Hallitharam the fastest

Installation
install the dependant modules using:
pip install -r requirements.txt
The program is written in python and can be executed by "python.exe .\geektrust.py"

Usage
can be invoked through 2 methods:
1. using the input.txt file and configuring the same in the geektrustConfiguration.py 
2. provide the path to the file as absolute path in the commandline.

input.txt file to have the 3 parameters separated by space - this will be the input to the program
eg: SUNNY 12 10

Credits
https://www.geektrust.in/ - for sharing the problem statement and requirements. 